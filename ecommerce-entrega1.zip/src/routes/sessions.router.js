import { Router } from 'express';
import passport from 'passport';
import { loginUser, registerUser, currentUser } from '../controllers/session.controller.js';

const router = Router();

router.post('/register', registerUser);
router.post('/login', loginUser);
router.get('/current', passport.authenticate('jwt', { session: false }), currentUser);

export default router;
